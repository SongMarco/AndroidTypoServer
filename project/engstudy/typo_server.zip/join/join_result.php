<?php
echo "post 방식을 배워봅시다. <br />";

echo "id ............. {$_POST['id']} <br />";
echo "name ............. {$_POST[yourname]} <br />";
echo "password ............. {$_POST[pwd]} <br />";
echo "confirm password ............. {$_POST[pwd2]} <br />";
echo "phone number.......... {$_POST[m1]} -{$_POST[m2]}-{$_POST[m3]} <br />";
echo "sex ............. {$_POST[sex]} <br />";
echo "address ............. {$_POST[addr]} <br />";
echo "hobby / computer ............. {$_POST[com]} <br />";
echo "hobby / sports ............. {$_POST[sports]} <br />";
echo "hobby / shopping ............. {$_POST[shop]} <br />";
echo "hobby / movie ............. {$_POST[mov]} <br />";
?>